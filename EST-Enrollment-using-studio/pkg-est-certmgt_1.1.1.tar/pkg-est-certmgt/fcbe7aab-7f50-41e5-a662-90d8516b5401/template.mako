<%doc>
Written By Shai Perretz 13.9.2025 
email: shaip@arista.com
This will create a configuration to use EST server and get a certifAdd general dot1x/radius configicate.
The auto generated certificate will used to connect to RADESC (AGNI) server. 
version 1.0.5
</%doc>

<%
from typing import List, Dict
from cloudvision.cvlib import ActionFailed
import grpc
import json
from arista.inventory.v1.services import ProvisionedDeviceServiceStub, ProvisionedDeviceRequest,ProvisionedDeviceStreamRequest
from arista.inventory.v1 import models
from google.protobuf.json_format import Parse
from google.protobuf import wrappers_pb2 as wrappers
 
def device_matches_resolver_query(resolver, device_id):
      if device_id and resolver:
            _, ctx_resolver = resolver.resolveWithContext(device_id)
      else:
            return False
      if ctx_resolver and ctx_resolver.query_str.strip() != "":
            return True
      else:
            return False

def GetDeviceIP():
      json_request = json.dumps({"key":{"deviceId": str(ctx.getDevice().id)}})
      req = Parse(json_request, ProvisionedDeviceRequest(), False)
      sw_stub = ctx.getApiClient(ProvisionedDeviceServiceStub)
      sw_properties = sw_stub.GetOne(req, timeout=30)
      return sw_properties.value.ip_address.value

ctx.info(f"strating getting vars")
isDeviceResolved = device_matches_resolver_query(applyDevicesResolver,ctx.getDevice().id )
if not isDeviceResolved:
      ctx.info(f"Switch is not listed on the device resolver, continue to next device")
      return

deviceip = GetDeviceIP()
hostname = ctx.getDeviceHostname()
mac = ctx.getDevice().mac 

ctx.info(f"ip: {deviceip}") 
ctx.info(f"mac: {mac}")
ctx.info(f"hostname: {hostname}")

if applyDevicesResolver:
      for server in applyDevicesResolver.resolve()['applyDevicesGroup'].items(): 
            ctx.info(f"server: {server}")
            if server[0] == 'certificateProperties': 
                  country = server[1]['country']
                  state = server[1]['state']
                  subjectAlternativeNameEmail = server[1]['subjectAlternativeNameEmail']
                  subjectAlternativeNameUri = server[1]['subjectAlternativeNameUri']
                  selfSignCertificateFileName = server[1]['selfSignCertificateFileName']
                  selfSignKeyFileName = server[1]['selfSignKeyFileName']
                  autoCertProfileName = server[1]['autoCertProfileName']
                   
            endif
            if server[0] == 'estServerDetails':
                  
                  estServerUrl = server[1]['estServerUrl'] 
                  estServerSourceVrf = server[1]['estServerSourceVrf']
                  estSslServerProfileName = server[1]['estSslServerProfileName']
                  radiusServerHostname = server[1]['radiusServerHostname']
                  radiusSslServerProfileName = server[1]['radiusSslServerProfileName']
                  radiusServerGroupName = server[1]['radiusServerGroupName']
                  radiusSourceInterface = server[1]['radiusSourceInterface']
                  radiusSourceVrf = server[1]['radiusSourceVrf']
            endif
            if server[0] == 'tokens':
                  enrollmentToken = server[1]['enrollmentToken']
                  reenrollmentToken = server[1]['reenrollmentToken'] 
            endif
            if server[0] == 'addGeneralDot1XRadiusConfig':
                  addGeneralDot1XRadiusConfig = server[1]
      endfor
endif

commonName = mac
%>

## add est configuration to device 
% if applyDevicesResolver:
management security
      auto-certificate protocol est ${estSslServerProfileName}
            server url ${estServerUrl}
% if estServerSourceVrf:
            server vrf ${estServerSourceVrf}
% endif
            server ssl profile ${estSslServerProfileName}
            credentials enroll token ${enrollmentToken}
            credentials re-enroll token ${reenrollmentToken}
!
       auto-certificate profile ${autoCertProfileName}
            key ${selfSignKeyFileName}
            parameters distinguished-name common-name ${commonName}
% if country:
            parameters distinguished-name country ${country}
% endif
% if state:
            parameters distinguished-name state ${state}
% endif
            parameters subject-alternative-name ip ${deviceip}
            parameters subject-alternative-name dns ${hostname}
% if subjectAlternativeNameEmail:
            parameters subject-alternative-name email ${subjectAlternativeNameEmail}
% endif
% if subjectAlternativeNameUri:
            parameters subject-alternative-name uri ${subjectAlternativeNameUri}
% endif
            protocol instance ${estSslServerProfileName}
!
## Configure the ssl profile used to mutual initial authentication with the EST server (AGNI) 
      ssl profile ${estSslServerProfileName}
            certificate ${selfSignCertificateFileName} key ${selfSignKeyFileName}
            trust certificate AGNI_https_server_cert_chain.pem  
!
## Configure the ssl profile used to mutual authentication with the RADESC server (AGNI)
      ssl profile ${radiusSslServerProfileName} 
            certificate auto-certificate ${autoCertProfileName}
            trust certificate radsec_ca_certificate.pem   
!
!
% endif

## add general dot1x and radius configuraion if user specified to do so
% if addGeneralDot1XRadiusConfig:
radius-server host ${radiusServerHostname} tls ssl-profile ${radiusSslServerProfileName}
aaa group server radius ${radiusServerGroupName}
   server ${radiusServerHostname} tls
!      
aaa authentication dot1x default group agni-server-group
aaa accounting dot1x default start-stop group agni-server-group 
!
dot1x system-auth-control
dot1x protocol lldp bypass
dot1x dynamic-authorization
dot1x
   radius av-pair service-type
   radius av-pair lldp system-name
   radius av-pair lldp system-description
## In case source interface is mentioned add source interface for radsec communication
% if radiusSourceInterface and radiusSourceVrf:
      ip radius vrf ${radiusSourceVrf} source-interface ${radiusSourceInterface}
% endif

%endif


      

 